package modelo;

import java.io.Serializable;

public enum Palo implements Serializable {
		ESPADA, BASTO,COPA,ORO
}
